package com.atguigu.daijia.payment.mapper;

import com.atguigu.daijia.model.entity.payment.ProfitsharingInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProfitsharingInfoMapper extends BaseMapper<ProfitsharingInfo> {


}
