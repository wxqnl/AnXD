package com.atguigu.daijia.payment.service;

public interface WxProfitsharingService {

}
