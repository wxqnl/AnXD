package com.atguigu.daijia.order.testLock;

public interface TestService {
    void testLock();
}
