package com.atguigu.daijia.dispatch.mapper;

import com.atguigu.daijia.model.entity.dispatch.OrderJob;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OrderJobMapper extends BaseMapper<OrderJob> {

}
