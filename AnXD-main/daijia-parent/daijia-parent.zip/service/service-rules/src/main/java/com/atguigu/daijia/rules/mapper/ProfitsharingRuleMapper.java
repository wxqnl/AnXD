package com.atguigu.daijia.rules.mapper;

import com.atguigu.daijia.model.entity.rule.ProfitsharingRule;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProfitsharingRuleMapper extends BaseMapper<ProfitsharingRule> {

}
